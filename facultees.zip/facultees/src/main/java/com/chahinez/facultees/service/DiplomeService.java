package com.chahinez.facultees.service;

import java.util.List;
import com.chahinez.facultees.entities.Diplome;
import com.chahinez.facultees.entities.Facultee;

public interface DiplomeService {
	
	Diplome saveDiplome(Diplome p);
	Diplome updateDiplome(Diplome p);
	void deleteDiplome(Diplome p);
	 void deleteDiplomeById(Long id);
	Diplome getDiplome(Long id);
	List<Diplome> getAllDiplomes();
	List<Diplome> findByNomDiplome(String nom);
	List<Diplome> findByNomDiplomeContains(String nom);
	List<Diplome> findByNomType (String nom, String type);
	List<Diplome> findByFacultee (Facultee cate);
	List<Diplome> findByFaculteeIdFacultee(Long id);
	List<Diplome> findByOrderByNomProduitAsc();
	List<Diplome> trierDiplomesNomsType();


}
