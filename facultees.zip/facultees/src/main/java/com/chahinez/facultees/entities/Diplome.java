package com.chahinez.facultees.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Diplome {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idDiplome;
	private String nomDiplome;
	private String prenomDiplome;
	private String typeDiplome;
	
	@ManyToOne
	private Facultee facultee;
	
	public Diplome() {
		super();
		}
	
		public Diplome(String nomDiplome, String prenomDiplome, String typeDiplome) {
		super();
		this.nomDiplome = nomDiplome;
		this.prenomDiplome = prenomDiplome;
		this.typeDiplome = typeDiplome;
		}
		
		public Long getIdDiplome() {
			return idDiplome;
		}
		
		public void setIdDiplome(Long idDiplome) {
		this.idDiplome = idDiplome;
		}
		
		public String getNomDiplome() {
		return nomDiplome;
		}
		
		public void setNomDiplome(String nomDiplome) {
		this.nomDiplome = nomDiplome;
		}
		
		public String getPrenomDiplome() {
			return prenomDiplome;
		}
			
		public void setPrenomDiplome(String prenomDiplome) {
			this.prenomDiplome = prenomDiplome;
		}
		
		public String getTypeDiplome() {
			return typeDiplome;
			}
			
		public void setTypeDiplome(String typeDiplome) {
			this.typeDiplome = typeDiplome;
		}
		
		@Override
		public String toString() {
		return "Diplome [idDiplome=" + idDiplome + ", nomDiplome=" + 
		nomDiplome + ", prenomDiplome=" + prenomDiplome
		+ ", typeDiplome=" + typeDiplome + "]";
		}

	

}
