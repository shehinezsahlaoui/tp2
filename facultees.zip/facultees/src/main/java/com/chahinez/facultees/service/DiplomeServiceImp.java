package com.chahinez.facultees.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chahinez.facultees.entities.Diplome;
import com.chahinez.facultees.entities.Facultee;
import com.chahinez.facultees.repos.DiplomeRepository;

@Service
public class DiplomeServiceImp implements DiplomeService {
	
	@Autowired
	DiplomeRepository diplomeRepository;
	
	@Override
	public Diplome saveDiplome(Diplome p) {
	return diplomeRepository.save(p);
	}
	@Override
	public Diplome updateDiplome(Diplome p) {
	return diplomeRepository.save(p);
	}
	@Override
	public void deleteDiplome(Diplome p) {
	diplomeRepository.delete(p);
	}
	 @Override
	public void deleteDiplomeById(Long id) {
	diplomeRepository.deleteById(id);
	}
	@Override
	public Diplome getDiplome(Long id) {
	return diplomeRepository.findById(id).get();
	}
	@Override
	public List<Diplome> getAllDiplomes() {
	return diplomeRepository.findAll();
	}
	@Override
	public List<Diplome> findByNomDiplome(String nom) {
		return diplomeRepository.findByNomDiplome(nom);
	}
	@Override
	public List<Diplome> findByNomDiplomeContains(String nom) {
		return diplomeRepository.findByNomDiplomeContains(nom);
	}
	@Override
	public List<Diplome> findByNomType(String nom, String type) {
		return diplomeRepository.findByNomType(nom, type);
	}
	@Override
	public List<Diplome> findByFacultee(Facultee cate) {
		return diplomeRepository.findByFacultee(cate);
	}
	@Override
	public List<Diplome> findByFaculteeIdFacultee(Long id) {
		return diplomeRepository.findByFaculteeIdFaculte(id);
	}
	@Override
	public List<Diplome> findByOrderByNomProduitAsc() {
		return diplomeRepository.findByOrderByNomDiplomeAsc();
	}
	@Override
	public List<Diplome> trierDiplomesNomsType() {
		return diplomeRepository.trierDiplomesNomsType();
	}


}
