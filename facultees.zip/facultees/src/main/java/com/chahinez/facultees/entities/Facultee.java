package com.chahinez.facultees.entities;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;


@Data
@AllArgsConstructor
@Entity
public class Facultee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idFaculte;
	private String nomFaculte;
	private String adresseFaculte;
	private String numFaculte ;
	private String faxFaculte ;
	
	@JsonIgnore
	@OneToMany(mappedBy = "facultee")
	private List<Diplome> diplomes;
	
	public Facultee() {}
	
	public Facultee(String nomFaculte, String adresseFaculte, String numFaculte, String faxFaculte,List<Diplome> diplomes ) {
		super();
		this.nomFaculte = nomFaculte;
		this.adresseFaculte = adresseFaculte;
		this.numFaculte = numFaculte;
		this.faxFaculte = faxFaculte;
		}
	
	public Long getIdFaculte() {
		return idFaculte;
	}
	
	public void setIdFaculte(Long idFaculte) {
		this.idFaculte = idFaculte;
	}
	
	public String getNomFaculte() {
		return nomFaculte;
	}
	
	public void setNomFaculte(String nomFaculte) {
		this.nomFaculte = nomFaculte;
	}
	
	public String getAdresseFaculte() {
		return adresseFaculte;
	}
	
	public void setAdresseFaculte(String adresseFaculte) {
		this.adresseFaculte = adresseFaculte;
	}
	
	public String getNumFaculte() {
		return numFaculte;
	}
	
	public void setNumFaculte(String numFaculte) {
		this.numFaculte = numFaculte;
	}
	
	public String getFaxFaculte() {
		return faxFaculte;
	}
	
	public void setFaxFaculte(String faxFaculte) {
		this.faxFaculte = faxFaculte;
	}
	
	public List<Diplome> getDiplomes() {
		return diplomes;
		}
	
		public void setProduits(List<Diplome> diplomes) {
		this.diplomes = diplomes;
		}

	
	
	

}
